export { SocialLoginButtons } from "./social-login-buttons";
