"use client";

import { useState, useEffect } from "react";
import { useSearchParams } from "next/navigation";
import { useBilling, SubscriptionStatus } from "@/hooks/useBilling";

const PLANS = [
  {
    id: "free",
    name: "Free",
    price: 0,
    period: "forever",
    features: [
      "1 team member",
      "1 integration",
      "7-day data retention",
      "Basic dashboard",
    ],
    cta: "Current Plan",
    highlighted: false,
  },
  {
    id: "starter",
    name: "Starter",
    price: 49,
    period: "/month",
    features: [
      "3 team members",
      "3 integrations",
      "30-day data retention",
      "Email reports",
      "Email support",
    ],
    cta: "Upgrade",
    highlighted: false,
  },
  {
    id: "pro",
    name: "Pro",
    price: 149,
    period: "/month",
    features: [
      "10 team members",
      "5 integrations",
      "1-year data retention",
      "Custom reports",
      "API access",
      "Priority support",
    ],
    cta: "Upgrade",
    highlighted: true,
  },
  {
    id: "agency",
    name: "Agency",
    price: 399,
    period: "/month",
    features: [
      "Unlimited team members",
      "Unlimited integrations",
      "Unlimited data retention",
      "White-label reports",
      "Dedicated support",
      "Custom onboarding",
    ],
    cta: "Contact Sales",
    highlighted: false,
  },
];

// Helper to get status badge styling
function getStatusBadgeStyle(status: SubscriptionStatus): string {
  switch (status) {
    case "active":
      return "bg-gh-success-subtle text-gh-success-fg";
    case "trialing":
      return "bg-gh-accent-subtle text-gh-accent-fg";
    case "past_due":
      return "bg-gh-attention-subtle text-gh-attention-fg";
    case "canceled":
    case "incomplete":
    case "incomplete_expired":
      return "bg-gh-canvas-subtle text-gh-text-secondary";
    default:
      return "bg-gh-canvas-subtle text-gh-text-secondary";
  }
}

// Helper to get human-readable status
function getStatusLabel(status: SubscriptionStatus): string {
  switch (status) {
    case "active":
      return "Active";
    case "trialing":
      return "Trial";
    case "past_due":
      return "Past Due";
    case "canceled":
      return "Canceled";
    case "incomplete":
      return "Incomplete";
    case "incomplete_expired":
      return "Expired";
    default:
      return status;
  }
}

export default function BillingPage() {
  const searchParams = useSearchParams();
  const { billing, loading, error, createCheckout, openPortal, reload } = useBilling();
  const [upgrading, setUpgrading] = useState<string | null>(null);
  const [notification, setNotification] = useState<{ type: "success" | "error"; message: string } | null>(null);

  // Handle checkout success/cancel from URL params
  useEffect(() => {
    const status = searchParams.get("status");
    if (status === "success") {
      setNotification({ type: "success", message: "Subscription activated successfully!" });
      reload();
      // Clear URL params
      window.history.replaceState({}, "", "/billing");
    } else if (status === "cancelled") {
      setNotification({ type: "error", message: "Checkout was cancelled." });
      window.history.replaceState({}, "", "/billing");
    }
  }, [searchParams, reload]);

  // Auto-clear notification
  useEffect(() => {
    if (notification) {
      const timer = setTimeout(() => setNotification(null), 5000);
      return () => clearTimeout(timer);
    }
  }, [notification]);

  const handleUpgrade = async (planId: string) => {
    if (planId === "free") return;
    if (planId === "agency") {
      window.location.href = "/contact?reason=agency";
      return;
    }
    
    setUpgrading(planId);
    try {
      await createCheckout(planId);
    } catch (err) {
      setNotification({ 
        type: "error", 
        message: err instanceof Error ? err.message : "Failed to start checkout" 
      });
      setUpgrading(null);
    }
  };

  const handleManageBilling = async () => {
    try {
      await openPortal();
    } catch (err) {
      setNotification({ 
        type: "error", 
        message: err instanceof Error ? err.message : "Failed to open billing portal" 
      });
    }
  };

  const currentPlan = billing?.plan || "free";
  const isPlanActive = (planId: string) => currentPlan === planId && billing?.status === "active";

  // Show not configured message if Stripe isn't set up
  if (!loading && billing && !billing.billingConfigured) {
    return (
      <div className="p-8">
        <div className="mb-8">
          <h1 className="text-2xl font-bold text-gh-text-primary dark:text-gh-text-primary-dark">Billing & Plans</h1>
          <p className="mt-1 text-gh-text-secondary dark:text-gh-text-secondary-dark">
            Manage your subscription and billing details
          </p>
        </div>
        <div className="rounded-md border border-gh-attention-emphasis bg-gh-attention-subtle p-6 text-center">
          <h2 className="text-lg font-semibold text-gh-attention-fg">Billing Not Yet Configured</h2>
          <p className="mt-2 text-gh-attention-fg">
            Payment processing is not yet set up for this instance. Please contact support for assistance.
          </p>
        </div>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="p-8">
        <div className="animate-pulse space-y-6">
          <div className="h-8 w-48 rounded bg-gh-canvas-subtle dark:bg-gh-canvas-subtle-dark" />
          <div className="grid gap-6 lg:grid-cols-4">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="h-96 rounded-md bg-gh-canvas-subtle dark:bg-gh-canvas-subtle-dark" />
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-8">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gh-text-primary dark:text-gh-text-primary-dark">Billing & Plans</h1>
        <p className="mt-1 text-gh-text-secondary dark:text-gh-text-secondary-dark">
          Manage your subscription and billing details
        </p>
      </div>

      {/* Notifications */}
      {notification && (
        <div
          className={`mb-6 rounded-md px-4 py-3 text-sm border ${
            notification.type === "success"
              ? "bg-gh-success-subtle text-gh-success-fg border-gh-success-emphasis"
              : "bg-gh-danger-subtle text-gh-danger-fg border-gh-danger-emphasis"
          }`}
        >
          {notification.message}
        </div>
      )}

      {error && (
        <div className="mb-6 rounded-md bg-gh-danger-subtle border border-gh-danger-emphasis px-4 py-3 text-sm text-gh-danger-fg">
          {error}
        </div>
      )}

      {/* Current Plan Status */}
      {billing && billing.status !== "none" && (
        <div className="mb-8 rounded-md border border-gh-border bg-gh-canvas-default p-6 dark:border-gh-border-dark dark:bg-gh-canvas-dark">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-3">
                <h2 className="text-lg font-semibold text-gh-text-primary dark:text-gh-text-primary-dark">
                  Current Plan: {billing.plan_name || currentPlan.charAt(0).toUpperCase() + currentPlan.slice(1)}
                </h2>
                <span
                  className={`rounded-full px-2 py-0.5 text-xs font-medium ${getStatusBadgeStyle(billing.status)}`}
                >
                  {getStatusLabel(billing.status)}
                </span>
              </div>
              {billing.trialEnd && billing.status === "trialing" && (
                <p className="mt-1 text-sm text-gh-text-secondary dark:text-gh-text-secondary-dark">
                  Trial ends on: {new Date(billing.trialEnd).toLocaleDateString()}
                </p>
              )}
              {billing.currentPeriodEnd && billing.status !== "trialing" && (
                <p className="mt-1 text-sm text-gh-text-secondary dark:text-gh-text-secondary-dark">
                  {billing.status === "canceled" ? "Access until" : "Next billing date"}:{" "}
                  {new Date(billing.currentPeriodEnd).toLocaleDateString()}
                </p>
              )}
            </div>
            {billing.stripeCustomerPortalAvailable && (
              <button
                onClick={handleManageBilling}
                className="rounded-md border border-gh-border px-4 py-2 text-sm font-medium text-gh-text-primary transition hover:bg-gh-canvas-subtle dark:border-gh-border-dark dark:text-gh-text-primary-dark dark:hover:bg-gh-canvas-subtle-dark"
              >
                Manage Billing
              </button>
            )}
          </div>
        </div>
      )}

      {/* Pricing Plans */}
      <div className="grid gap-6 lg:grid-cols-4">
        {PLANS.map((plan) => {
          const isCurrentPlan = isPlanActive(plan.id);
          const canUpgrade = !isCurrentPlan && plan.id !== "free";
          
          return (
            <div
              key={plan.id}
              className={`relative rounded-md border bg-gh-canvas-default p-6 transition dark:bg-gh-canvas-dark ${
                plan.highlighted
                  ? "border-brand-500 ring-2 ring-brand-500"
                  : isCurrentPlan
                  ? "border-brand-300 bg-brand-50 dark:bg-brand-900/10"
                  : "border-gh-border dark:border-gh-border-dark"
              }`}
            >
              {plan.highlighted && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2 rounded-full bg-brand-500 px-3 py-0.5 text-xs font-semibold text-white">
                  Most Popular
                </div>
              )}

              <div className="mb-4">
                <h3 className="text-lg font-semibold text-gh-text-primary dark:text-gh-text-primary-dark">{plan.name}</h3>
                <div className="mt-2">
                  <span className="text-3xl font-bold text-gh-text-primary dark:text-gh-text-primary-dark">${plan.price}</span>
                  <span className="text-gh-text-secondary dark:text-gh-text-secondary-dark">{plan.period}</span>
                </div>
              </div>

              <ul className="mb-6 space-y-3">
                {plan.features.map((feature, i) => (
                  <li key={i} className="flex items-start gap-2 text-sm text-gh-text-secondary dark:text-gh-text-secondary-dark">
                    <svg
                      className="mt-0.5 h-4 w-4 flex-shrink-0 text-brand-500"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M5 13l4 4L19 7"
                      />
                    </svg>
                    {feature}
                  </li>
                ))}
              </ul>

              <button
                onClick={() => canUpgrade && handleUpgrade(plan.id)}
                disabled={isCurrentPlan || upgrading === plan.id || plan.id === "free"}
                className={`w-full rounded-md px-4 py-2.5 text-sm font-semibold transition ${
                  isCurrentPlan
                    ? "cursor-default bg-brand-100 text-brand-700 dark:bg-brand-900/30 dark:text-brand-300"
                    : plan.id === "free"
                    ? "cursor-default bg-gh-canvas-subtle text-gh-text-tertiary dark:bg-gh-canvas-subtle-dark dark:text-gh-text-tertiary-dark"
                    : plan.highlighted
                    ? "bg-brand-500 text-white hover:bg-brand-600 disabled:opacity-50"
                    : "border border-gh-border text-gh-text-primary hover:bg-gh-canvas-subtle dark:border-gh-border-dark dark:text-gh-text-primary-dark dark:hover:bg-gh-canvas-subtle-dark disabled:opacity-50"
                }`}
              >
                {upgrading === plan.id
                  ? "Redirecting..."
                  : isCurrentPlan
                  ? "Current Plan"
                  : plan.id === "free"
                  ? "Free Forever"
                  : plan.cta}
              </button>
            </div>
          );
        })}
      </div>

      {/* FAQ / Help */}
      <div className="mt-12 rounded-md border border-gh-border bg-gh-canvas-default p-6 dark:border-gh-border-dark dark:bg-gh-canvas-dark">
        <h3 className="text-lg font-semibold text-gh-text-primary dark:text-gh-text-primary-dark">Frequently Asked Questions</h3>
        <div className="mt-4 grid gap-6 md:grid-cols-2">
          <div>
            <h4 className="font-medium text-gh-text-primary dark:text-gh-text-primary-dark">Can I change plans anytime?</h4>
            <p className="mt-1 text-sm text-gh-text-secondary dark:text-gh-text-secondary-dark">
              Yes! You can upgrade or downgrade your plan at any time. Changes take effect immediately.
            </p>
          </div>
          <div>
            <h4 className="font-medium text-gh-text-primary dark:text-gh-text-primary-dark">What happens when I cancel?</h4>
            <p className="mt-1 text-sm text-gh-text-secondary dark:text-gh-text-secondary-dark">
              Your subscription remains active until the end of your billing period. Your data is retained for 30 days.
            </p>
          </div>
          <div>
            <h4 className="font-medium text-gh-text-primary dark:text-gh-text-primary-dark">Do you offer refunds?</h4>
            <p className="mt-1 text-sm text-gh-text-secondary dark:text-gh-text-secondary-dark">
              We offer a 14-day money-back guarantee. Contact support within 14 days for a full refund.
            </p>
          </div>
          <div>
            <h4 className="font-medium text-gh-text-primary dark:text-gh-text-primary-dark">Need help choosing?</h4>
            <p className="mt-1 text-sm text-gh-text-secondary dark:text-gh-text-secondary-dark">
              <a href="/contact" className="text-brand-500 hover:text-brand-600 dark:text-brand-400 dark:hover:text-brand-300">
                Contact our sales team
              </a>{" "}
              for personalized recommendations.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
